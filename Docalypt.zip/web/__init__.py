"""Docalypt Web Application Package."""
